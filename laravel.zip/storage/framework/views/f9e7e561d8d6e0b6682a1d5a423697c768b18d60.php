<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<?php /**PATH E:\laravel\plin-plan\resources\views/no-reload/body-up.blade.php ENDPATH**/ ?>