<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<?php /**PATH E:\laravel\plin-plan\resources\views/no-reload/head.blade.php ENDPATH**/ ?>