<?php $__env->startSection('title'); ?>
    Belanja
<?php $__env->stopSection(); ?>

<?php $__env->startSection('misc'); ?>
    <?php echo $__env->make('no-reload.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .data-numeric {
            text-align: right;
        }

        .bg-fade {
            background-color: rbga(0, 0, 0, 1)
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('no-reload.body-up', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php
    $cat = ['Makanan', 'Minuman', 'Rokok', 'Lainnya'];
    ?>

    <section class="section">

        <div class="card">
            <div class="card-body">
                <div class="card-title">
                    <nav class="">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('belanja')); ?>">Belanja</a></li>
                            <li class="breadcrumb-item active">Rencana Belanja</li>
                        </ol>
                    </nav>
                    Daftar Rencana Belanja
                    <div class="text-muted small" style="font-size:;">
                        <?php if($rencana->unique('group')->count() == 0): ?>
                            Kamu tidak punya rencana belanja
                        <?php else: ?>
                            Kamu punya <?php echo e($rencana->unique('group')->count()); ?> rencana belanja
                        <?php endif; ?>
                    </div>
                </div>
                <section class="section">
                    <div class="d-block d-md-flex" style='gap: 10px'>
                        <div class='d-flex' style="gap: 10px; margin-bottom: 10px;">
                            <a href="/belanja/rencana" style="display: flex; align-items: center; gap: 5px;"
                                class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambah-rencana">
                                <strong><i class="bi
                                bi-box-arrow-in-down"></i></strong>
                                Tambah Daftar</a>
                        </div>
                </section>
                <div class="border-bottom"></div>
                <section class="section">
                    <?php if($rencana->count() == 0): ?>
                        <div class="text-center mt-3">
                            Belum ada daftar rencana
                        </div>
                    <?php else: ?>
                        <table id='item-container' class="table table-borderless table-striped table-hover"
                            style="width: 100%">
                            <thead>
                                <tr>
                                    <th>Grup</th>
                                    <th>Waktu</th>
                                    <th class="text-center">Jumlah Item</th>
                                    <th class="text-center">Total</th>
                                    <th>&nbsp;</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php $__currentLoopData = $rencana->unique('group'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="vertical-align: middle" class="text-center"><?php echo e($item->group); ?></td>
                                        <td style="vertical-align: middle">
                                            <?php echo e(\Carbon\Carbon::parse($item->created_at)->locale('id')->isoFormat('dddd, D MMMM YYYY [pukul] H:mm:ss')); ?>

                                        </td>
                                        <td style="vertical-align: middle" class="text-center">
                                            <?php echo e($rencana->where('group', $item->group)->count()); ?>

                                        </td>
                                        <td style="vertical-align: middle" class="text-center">
                                            <span class="badge bg-danger">Rp
                                                <?php echo e($rencana->where('group', $item->group)->sum(function ($row) {
                                                    return $row->qty * $row->harga_awal;
                                                })); ?>

                                            </span>
                                        </td>
                                        <td style="vertical-align: middle">
                                            <button class="btn btn-secondary"><i class="bi bi-eye"></i></button>
                                            <button ondblclick="submitRencana(this)"
                                                <?php if($item->status == 0): ?> class="btn btn-warning"
                                            <?php else: ?> disabled='true' class="btn btn-success" <?php endif; ?>>Selesai</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </section>
    <script>
        function submitRencana(button) {
            var uncle = button.parentNode.parentNode.querySelectorAll('td');

            $.ajax({
                url: '/belanja/submit-rencana',
                method: 'POST',
                data: {
                    kode: Number(uncle[0].innerText)
                },
                success: (res) => {
                    button.disabled = true;
                    button.classList.add('btn-success')
                    button.classList.remove('btn-warning')
                },
                error: (err) => {
                    console.error(err)
                }
            })
        }
    </script>

    <?php echo $__env->make('content.belanja.tambah-rencana', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\plin-plan\resources\views/content/belanja/rencana.blade.php ENDPATH**/ ?>