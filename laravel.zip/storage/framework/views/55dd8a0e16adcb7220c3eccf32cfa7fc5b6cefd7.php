<?php
    $popularItems = $transactions
        ->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()])
        ->sortByDesc('qty')
        ->take(5);
?>

<div class="col-12">
    <div class="card top-selling overflow-auto">

        <?php
        $cat = ['Makanan', 'Minuman', 'Rokok', 'Lainnya'];
        ?>
        <div class="card-body pb-0">
            <h5 class="card-title">Item Terpopuler Minggu Ini</h5>

            <table id='item-container' class="table table-hover" style="width: 100%">
                <thead>
                    <tr>
                        <th>Preview</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th>Keluar</th>
                        <th>Pendapatan</th>
                    </tr>
                </thead>
                <tbody style="width: 100%">
                    <?php $__currentLoopData = $popularItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="width: 100" id='row<?php echo e($item->kode); ?>'>
                            <td>
                                <img src="<?php echo e($item->foto); ?>" width='50' class=""
                                    style="border-radius: 5px; border: 1px solid darkgray">
                            </td>

                            
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($cat[$item->kategori]); ?></td>
                            <td class="data-numeric
                                    text-center"><?php echo e($item->qty); ?>

                            </td>
                            <td class="data-numeric text-center text-success">
                                <span class="fw-bold" style="display: flex; justify-content: center; "><span>
                                    </span><span>Rp <?php echo e(number_format($item->qty * $item->harga_jual)); ?></span></span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

    </div>
</div>
<?php /**PATH E:\laravel\plin-plan\resources\views/content/main-component/popular-item.blade.php ENDPATH**/ ?>